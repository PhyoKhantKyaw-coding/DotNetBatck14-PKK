import Notiflix from '../index.d';
export = Notiflix;
export as namespace Notiflix;
